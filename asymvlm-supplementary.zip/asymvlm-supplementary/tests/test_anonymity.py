"""Double-blind check: no author, institution, or cluster identifiers in the repo."""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Assembled from fragments so this file does not match itself.
_FRAGMENTS = [
    ("abg", "ulhan"), ("gu", "lhan"), ("psu", r"\.edu"), ("kande", "mir"), ("yi", "lin"),
    ("/lus", "/eagle"), ("al", "cf"), ("pola", "ris"), ("sophia", "-gpu"), ("datascience", "_collab"),
]
PATTERN = re.compile("|".join(a + b for a, b in _FRAGMENTS), re.IGNORECASE)

SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", ".ipynb_checkpoints", ".mypy_cache"}
BINARY_SUFFIXES = {".pt", ".pth", ".bin", ".safetensors", ".ckpt", ".npy", ".npz", ".pkl",
                   ".png", ".jpg", ".jpeg", ".gif", ".pdf", ".zip", ".gz", ".tar", ".so",
                   ".pyc", ".parquet", ".arrow", ".h5"}
MAX_BYTES = 20 * 1024 * 1024


def _text_files():
    for path in ROOT.rglob("*"):
        rel = path.relative_to(ROOT)
        if any(part in SKIP_DIRS for part in rel.parts) or not path.is_file():
            continue
        if path.suffix.lower() in BINARY_SUFFIXES or path.stat().st_size > MAX_BYTES:
            continue
        data = path.read_bytes()
        if b"\0" in data[:8192]:
            continue
        yield rel, data.decode("utf-8", errors="replace")


def test_no_identifying_strings():
    offenders = []
    for rel, text in _text_files():
        if PATTERN.search(rel.as_posix()):
            offenders.append(f"{rel}: <path>")
        for lineno, line in enumerate(text.splitlines(), 1):
            if PATTERN.search(line):
                offenders.append(f"{rel}:{lineno}: {line.strip()[:160]}")
    assert not offenders, (f"{len(offenders)} identifying line(s):\n" + "\n".join(offenders[:200]))
